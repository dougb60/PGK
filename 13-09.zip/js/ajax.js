window.onload = function() {
	
	document.getElementById("ajax").on
}