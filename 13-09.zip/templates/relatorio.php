<?
include_once 'includes/header.php';

$dao = new RelatorioDao();

/* Lista todos */
$listaProj = $dao->listaProj($_SESSION["usuario_logado"]);
foreach ($listaProj as $key => $objeto){
	
}
/* Lista abertos */
$listaProj = $dao->listaProjAbto($_SESSION["usuario_logado"]);
foreach ($listaProj as $key => $objetoA){

}
/* Lista processando */
$listaProj = $dao->listaProjPcdo($_SESSION["usuario_logado"]);
foreach ($listaProj as $key => $objetoP){

}
/* Lista finalizado */
$listaProj = $dao->listaProjFin($_SESSION["usuario_logado"]);
foreach ($listaProj as $key => $objetoF){

}
/* Tarefas X Projeto */
/* seleciona ID usuario */
$udao = new UsuarioDao();
$usuid = $udao->listar($_SESSION["usuario_logado"]);
/* Traz o selec com numero de tarefas X projetos */
foreach ($usuid as $key => $usuid){}
$listaProj = $dao->listaTarefProj($usuid);
/* separa os objetos 
$listaProjE = array_values($listaProj);
var_dump($listaProjE);die();*/
$array = array();
foreach ($listaProj as $key => $lista){
	$array[] = $lista->total_tarefa;
}
$imp = implode("','",$array);
$tarefas = "'$imp'";
var_dump($tarefas);die();

?>
<div id="page-wrapper">
    <div class="container-fluid ">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                       <h1 class="page-header">
                            <?= $_SESSION["usuario_logado"]?>
                       </h1>	
                    </div>
                </div>
                  <div class = "col-sm-3 text-center box">
                	<i class="fa fa-archive fa-2x" aria-hidden="true"></i>
                	<div class="linha"></div>
                	<h3>Total de Projetos</h3>
                	<h4><?= $objeto->total_projeto?></h4>
                </div>
                <div class = "col-sm-3 text-center box2">
                	<i class="fa fa-hourglass-start fa-2x" aria-hidden="true"></i>
                	<div class="linha"></div>
                	<h3>Projetos Aguardando</h3>
                	<h4><?= $objetoA->total_abto?></h4>
                </div>
                <div class = "col-sm-3 text-center box3">
                	<i class="fa fa-hourglass-half fa-2x" aria-hidden="true"></i>
                	<div class="linha"></div>
                	<h3>Projetos Processando</h3>
                	<h4><?= $objetoP->total_pcdo?></h4>
                </div>
                <div class = "col-sm-3 text-center box4">
                	<i class="fa fa-hourglass-end fa-2x" aria-hidden="true"></i>
                	<div class="linha"></div>
                	<h3>Projetos Finalizados</h3>
                	<h4><?= $objetoF->total_fin?></h4>
                </div>
<? include_once 'includes/footer.php'; ?>

