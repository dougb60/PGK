<html>
	<head>	
		<script src="../js/jquery-1.12.3.js" type="text/javascript"></script>
		<script src="../js/jquery.dataTables.js" type="text/javascript"></script>
		<script>
			$(document).ready(function(){
				$('#teste').DataTable()
				});
		</script>
	</head>
	<body>
		<table id="teste">
			<thead>
				<tr>
					<th>teste 1</th>
					<th>teste 2</th>
					<th>teste 3</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>teste 1</td>
					<td>teste 2</td>
					<td>teste 3</td>
				</tr>
			</tbody>
		</table>
	</body>
</html>